

enum WeatherBotError: Error {
    case unKnowIntent
    case weatherManagerDictionary
    case aiManagerDictionary
    case geocodingManagerDictionary
}
